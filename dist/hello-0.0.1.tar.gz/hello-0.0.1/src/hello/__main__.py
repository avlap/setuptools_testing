from . import hello_world

if __name__ == '__main__':
    hello_world()
